// WhatsApp-style demo client. Sends what the "customer" does to /api/message,
// which runs the real bot (src/bot.js) and returns what it would have sent on WhatsApp.

const $ = (s) => document.querySelector(s);
const app = $("#app");
const messagesEl = $("#messages");
const input = $("#input");
const composer = $(".composer");
const statusEl = $("#status");

const BUSINESS = "Coffee Wagera";
const newId = () => (crypto.randomUUID?.() ?? Math.random().toString(36).slice(2) + Date.now().toString(36)).replace(/[^\w-]/g, "");
let sessionId = newId();
let lastSide = null;
let queue = Promise.resolve();
let pending = 0;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const time = () => new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }).toLowerCase();
const icon = (id, cls = "ic") => `<svg class="${cls}"><use href="#${id}"/></svg>`;
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

// WhatsApp formatting: *bold* _italic_ ~strike~ ```mono``` and auto-linked URLs.
function format(text) {
  const src = String(text).replace(/\*\*(.+?)\*\*/g, "*$1*");
  return src
    .split(/(https?:\/\/[^\s<]*[^\s<.,!?)\]'"])/g)
    .map((part, i) => {
      if (i % 2) return `<a href="${esc(part)}" target="_blank" rel="noopener">${esc(part)}</a>`;
      return esc(part)
        .replace(/```([^`]+?)```/g, "<code>$1</code>")
        .replace(/(^|[\s(>])\*(?!\s)([^*\n]+?)\*(?=$|[\s).,!?:;<])/g, "$1<strong>$2</strong>")
        .replace(/(^|[\s(>])_(?!\s)([^_\n]+?)_(?=$|[\s).,!?:;<])/g, "$1<em>$2</em>")
        .replace(/(^|[\s(>])~(?!\s)([^~\n]+?)~(?=$|[\s).,!?:;<])/g, "$1<s>$2</s>");
    })
    .join("");
}
const plain = (text) => String(text).replace(/[*_~`]/g, "").split("\n").find((l) => l.trim()) ?? "";

// ── Wallpaper doodles (generated SVG tile, recoloured per theme) ─────────────
function setWallpaper() {
  const c = getComputedStyle(document.documentElement).getPropertyValue("--doodle").trim() || "#d8cfc3";
  const s = `stroke='${c}' stroke-width='1.6' fill='none' stroke-linecap='round' stroke-linejoin='round'`;
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300' viewBox='0 0 300 300'><g ${s}>
    <path d='M20 40h30v22a12 12 0 0 1-12 12h-6a12 12 0 0 1-12-12z M50 46h6a7 7 0 0 1 0 14h-6 M28 30c0-6 6-6 6-12 M38 30c0-6 6-6 6-12'/>
    <path d='M120 30l5 11 12 2-9 8 2 12-10-6-10 6 2-12-9-8 12-2z'/>
    <path d='M215 30c-8-10-24 0-14 14l14 14 14-14c10-14-6-24-14-14z'/>
    <ellipse cx='270' cy='60' rx='12' ry='17' transform='rotate(30 270 60)'/><path d='M262 48c8 6 8 18 16 24'/>
    <path d='M30 130h40a8 8 0 0 1 8 8v18a8 8 0 0 1-8 8H48l-10 9v-9h-8a8 8 0 0 1-8-8v-18a8 8 0 0 1 8-8z'/>
    <circle cx='140' cy='140' r='18'/><path d='M132 136h.1 M148 136h.1 M131 147c5 6 13 6 18 0'/>
    <path d='M205 120v34a8 6 0 1 1-4-5v-22l22-5v22a8 6 0 1 1-4-5v-20'/>
    <path d='M260 150c0-20 20-30 30-30 0 20-10 30-30 30z M260 150l18-18'/>
    <ellipse cx='45' cy='240' rx='11' ry='16' transform='rotate(-25 45 240)'/><path d='M38 228c7 5 6 18 14 24'/>
    <path d='M110 220h44l-6 50h-32z M108 220h48 M126 220l6-14'/>
    <path d='M205 230a20 20 0 1 0 40 0 20 20 0 1 0-40 0 M215 222c3-3 7-3 10 0 M232 222c3-3 7-3 10 0'/>
    <path d='M275 260l8-16 8 16-8 16z'/>
    <circle cx='95' cy='85' r='4'/><circle cx='180' cy='190' r='4'/><circle cx='255' cy='205' r='3'/><circle cx='80' cy='190' r='3'/>
  </g></svg>`;
  messagesEl.style.backgroundImage = `url("data:image/svg+xml,${encodeURIComponent(svg.replace(/\s+/g, " "))}")`;
}
setWallpaper();
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", setWallpaper);

// ── Chat list ────────────────────────────────────────────────────────────────
const OTHER_CHATS = [
  ["Ahmed", "Bro kal ka plan pakka? 😄", "Yesterday"],
  ["Family", "Ammi: Dinner pe sab time pe aa jana", "Yesterday"],
  ["Office Team", "Sara: Slides shared in the drive 👍", "Monday"],
  ["Hamza", "Voice call", "Sunday"],
  ["Ayesha", "Thank you so much! 🙏", "12/10/2026"],
];
const cwRow = { preview: "Tap to chat with Coffee Wagera ☕", time: "", unread: 1, ticks: null };

function renderChatList() {
  const tk = cwRow.ticks ? icon(cwRow.ticks === "read" ? "i-ticks" : "i-tick", `tk ${cwRow.ticks === "read" ? "read" : ""}`) : "";
  $("#chatList").innerHTML =
    `<li class="chat-row active" id="cwRow">
      <img class="avatar" src="avatar.svg" alt="">
      <div class="row-main">
        <div class="row-top"><div class="row-name"><span>${BUSINESS}</span><svg class="badge"><use href="#i-verified"/></svg></div>
          <span class="row-time ${cwRow.unread ? "unread" : ""}">${cwRow.time}</span></div>
        <div class="row-bottom"><div class="row-preview">${tk}<span>${esc(cwRow.preview)}</span></div>
          ${cwRow.unread ? `<span class="unread-badge">${cwRow.unread}</span>` : ""}</div>
      </div></li>` +
    OTHER_CHATS.map(([name, prev, t]) =>
      `<li class="chat-row"><svg class="ph" viewBox="0 0 212 212"><use href="#i-person"/></svg>
        <div class="row-main"><div class="row-top"><div class="row-name"><span>${esc(name)}</span></div><span class="row-time">${t}</span></div>
        <div class="row-bottom"><div class="row-preview"><span>${esc(prev)}</span></div></div></div></li>`).join("");
  $("#cwRow").onclick = openChat;
}

function updatePreview(text, ticks = null) {
  cwRow.preview = plain(text);
  cwRow.time = time();
  cwRow.ticks = ticks;
  cwRow.unread = app.classList.contains("view-list") && !ticks ? cwRow.unread + 1 : 0;
  renderChatList();
}

function openChat() {
  app.classList.remove("view-list");
  app.classList.add("view-chat");
  cwRow.unread = 0;
  renderChatList();
  scrollDown();
}
$("#backBtn").onclick = () => {
  app.classList.remove("view-chat");
  app.classList.add("view-list");
};

// ── Message rendering ────────────────────────────────────────────────────────
function scrollDown() {
  requestAnimationFrame(() => messagesEl.scrollTo({ top: messagesEl.scrollHeight, behavior: "smooth" }));
}

function chip(html, cls = "") {
  const el = document.createElement("div");
  el.className = `chip ${cls}`;
  el.innerHTML = html;
  messagesEl.appendChild(el);
  lastSide = null;
}

function row(side, bubbleHtml, interactive = false) {
  const el = document.createElement("div");
  el.className = `row ${side}${lastSide !== side ? " tail" : ""}`;
  el.innerHTML = `<div class="bubble${interactive ? " interactive" : ""}">${bubbleHtml}</div>`;
  messagesEl.appendChild(el);
  lastSide = side;
  scrollDown();
  return el;
}

const meta = (ticks) =>
  `<span class="meta">${time()}${ticks ? `<svg class="tk"><use href="#i-tick"/></svg>` : ""}</span>`;

function addIncoming(m) {
  const body = `<div class="content"><div class="text">${format(m.body)}${m.footer ? "" : '<span class="spacer"></span>'}</div>` +
    (m.footer ? `<div class="footer-text">${esc(m.footer)}<span class="spacer"></span></div>` : "") +
    `${meta(false)}</div>`;

  if (m.kind === "text") return row("in", body);

  let actions = "";
  if (m.kind === "buttons") {
    actions = m.buttons.map((b, i) => `<button class="action" data-i="${i}">${icon("i-reply")}${esc(b.title)}</button>`).join("");
  } else if (m.kind === "list") {
    actions = `<button class="action" data-list>${icon("i-list")}${esc(m.button)}</button>`;
  } else if (m.kind === "link") {
    actions = `<a class="action" href="${esc(m.url)}" target="_blank" rel="noopener">${icon("i-open")}${esc(m.label)}</a>`;
  }
  const el = row("in", body + `<div class="actions">${actions}</div>`, true);

  if (m.kind === "buttons") {
    el.querySelectorAll("[data-i]").forEach((btn) => {
      btn.onclick = () => {
        const b = m.buttons[Number(btn.dataset.i)];
        addOutgoing({ text: b.title, quote: m.body });
        send({ type: "interactive", id: b.id }, b.title);
      };
    });
  }
  if (m.kind === "list") el.querySelector("[data-list]").onclick = () => openList(m);
}

function addOutgoing({ text, quote, sub }) {
  const q = quote ? `<div class="quote"><div class="quote-name">${BUSINESS}</div><div class="quote-text">${esc(plain(quote))}</div></div>` : "";
  const el = row("out",
    `${q}<div class="content"><div class="text">${format(text)}${sub ? "" : '<span class="spacer"></span>'}</div>` +
    (sub ? `<div class="sub">${esc(sub)}<span class="spacer"></span></div>` : "") +
    `${meta(true)}</div>`);
  updatePreview(text, "sent");
  return el;
}

const TICK_ORDER = ["sent", "delivered", "read"];
function setTicks(el, state) {
  const tk = el?.querySelector(".meta .tk");
  if (!tk || TICK_ORDER.indexOf(state) <= TICK_ORDER.indexOf(tk.dataset.state ?? "sent")) return;
  tk.dataset.state = state;
  tk.querySelector("use").setAttribute("href", state === "sent" ? "#i-tick" : "#i-ticks");
  tk.classList.toggle("read", state === "read");
}

function setTyping(on) {
  statusEl.textContent = on ? "typing…" : "Business account";
  statusEl.classList.toggle("typing", on);
}

// ── List picker ──────────────────────────────────────────────────────────────
const sheet = $("#sheet");
let sheetChoice = null;

function openList(m) {
  sheetChoice = null;
  $("#sheetTitle").textContent = m.button;
  $("#sheetSend").classList.remove("show");
  $("#sheetBody").innerHTML = m.sections.map((s, si) =>
    `${m.sections.length > 1 || s.title ? `<div class="sheet-section">${esc(s.title)}</div>` : ""}` +
    s.rows.map((r, ri) =>
      `<button class="sheet-row" data-s="${si}" data-r="${ri}"><div class="r-text"><div class="r-title">${esc(r.title)}</div>` +
      `${r.description ? `<div class="r-desc">${esc(r.description)}</div>` : ""}</div><span class="radio"></span></button>`).join("")
  ).join("");
  $("#sheetBody").querySelectorAll(".sheet-row").forEach((el) => {
    el.onclick = () => {
      $("#sheetBody").querySelectorAll(".selected").forEach((x) => x.classList.remove("selected"));
      el.classList.add("selected");
      sheetChoice = m.sections[el.dataset.s].rows[el.dataset.r];
      $("#sheetSend").classList.add("show");
    };
    el.ondblclick = () => sendChoice(m);
  });
  $("#sheetSend").onclick = () => sendChoice(m);
  sheet.hidden = false;
}
function sendChoice(m) {
  if (!sheetChoice) return;
  const r = sheetChoice;
  closeList();
  addOutgoing({ text: r.title, sub: r.description, quote: m.body });
  send({ type: "interactive", id: r.id }, r.title);
}
function closeList() { sheet.hidden = true; }
$("#sheetClose").onclick = closeList;
sheet.onclick = (e) => { if (e.target === sheet) closeList(); };

// ── Talking to the bot ───────────────────────────────────────────────────────
function send(message, _label) {
  const outEl = messagesEl.lastElementChild;
  pending++;
  setTimeout(() => setTicks(outEl, "delivered"), 150);
  queue = queue.then(() => exchange(message, outEl));
}

async function exchange(message, outEl) {
  await sleep(250);
  setTicks(outEl, "read");
  updatePreview(cwRow.preview, "read");
  setTyping(true);
  let data;
  try {
    const res = await fetch("/api/message", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, message }),
    });
    data = await res.json();
    if (!res.ok) throw new Error(data.error || res.statusText);
  } catch (e) {
    setTyping(false);
    pending--;
    chip(esc(`⚠️ ${e.message || "Couldn't reach the bot server"}`), "notice");
    return;
  }

  for (const [i, m] of data.messages.entries()) {
    await sleep(i === 0 ? 450 : 700);
    addIncoming(m);
    updatePreview(m.body);
  }
  pending--;
  if (!pending) setTyping(false);
  if (data.staffNotified) toast("📣 The Coffee Wagera team was notified on WhatsApp");
}

function sendText() {
  const text = input.value.trim();
  if (!text) return;
  input.value = "";
  autosize();
  addOutgoing({ text });
  send({ type: "text", text });
  input.focus();
}

// ── Composer ─────────────────────────────────────────────────────────────────
function autosize() {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 120) + "px";
  composer.classList.toggle("has-text", input.value.trim().length > 0);
}
input.addEventListener("input", autosize);
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    sendText();
  }
});
$("#sendBtn").onclick = () => (input.value.trim() ? sendText() : toast("Voice messages aren't available in this demo"));

const EMOJIS = "😀 😂 😍 🥰 😊 😎 🤩 🙏 👍 👌 🙌 ❤️ 🔥 ☕ 🧋 🍪 🥐 🍫 🎂 🎉 😋 🤔 😅 😢".split(" ");
const emojiPanel = $("#emojiPanel");
emojiPanel.innerHTML = EMOJIS.map((e) => `<button>${e}</button>`).join("");
emojiPanel.onclick = (e) => {
  if (e.target.tagName !== "BUTTON") return;
  const { selectionStart: a, selectionEnd: b, value } = input;
  input.value = value.slice(0, a) + e.target.textContent + value.slice(b);
  input.selectionStart = input.selectionEnd = a + e.target.textContent.length;
  autosize();
  input.focus();
};
$("#emojiBtn").onclick = (e) => { e.stopPropagation(); emojiPanel.classList.toggle("open"); };

// ── Header menu, drawer, misc ────────────────────────────────────────────────
const dropdown = $("#dropdown");
$("#menuBtn").onclick = (e) => { e.stopPropagation(); dropdown.classList.toggle("open"); };
document.addEventListener("click", (e) => {
  dropdown.classList.remove("open");
  if (!emojiPanel.contains(e.target)) emojiPanel.classList.remove("open");
});
dropdown.onclick = (e) => {
  const act = e.target.dataset.act;
  if (act === "clear") resetChat();
  if (act === "info") $("#drawer").classList.add("open");
};
$("#whoBtn").onclick = () => $("#drawer").classList.add("open");
$("#drawerClose").onclick = () => $("#drawer").classList.remove("open");
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  closeList();
  $("#drawer").classList.remove("open");
});
document.querySelectorAll(".icon-btn:not([id]), .rail-btn:not(.active)").forEach((b) => {
  b.addEventListener("click", () => toast("Not available in this demo"));
});

let toastTimer;
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2600);
}

function intro() {
  messagesEl.innerHTML = "";
  lastSide = null;
  chip("Today", "date");
  chip(`${icon("i-lock")}Messages and calls are end-to-end encrypted. Only people in this chat can read, listen to, or share them.`, "notice");
  chip(`This business uses a secure service from Meta to manage this chat. Tap to learn more.`, "notice");
}

function resetChat() {
  sessionId = newId();
  queue = Promise.resolve();
  pending = 0;
  setTyping(false);
  intro();
  Object.assign(cwRow, { preview: "Tap to chat with Coffee Wagera ☕", time: "", unread: 0, ticks: null });
  renderChatList();
  input.value = "Hi";
  autosize();
}

// Start like a wa.me link with a pre-filled "Hi".
intro();
renderChatList();
input.value = "Hi";
autosize();
if (matchMedia("(min-width: 761px)").matches) input.focus();
